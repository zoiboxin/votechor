'use client'

import { useEffect, useState } from 'react'
import { useGameStore, uiActions } from '@/lib/game-store'
import { archetypeById } from '@/game/shared/constants'
import { KeyRound, HeartPulse, ShieldAlert, X, Route, Users, Copy, Check, LogOut, Flag, Ticket, Megaphone, Gift, UserPlus, Link2, Bot as BotIcon, Globe } from 'lucide-react'
import { motion } from 'framer-motion'

const TIPS = [
  'Hold E next to a DETAINED teammate to bail them out. No bribe required — the paperwork is free today.',
  'Squadmates get green name tags in the world. Spot your cell instantly in a stampede.',
  'Press RALLY to teleport to the nearest free cellmate — 45s cooldown between rallies.',
  'Press F (or the GIFT button) to hand your best item to the nearest teammate. Row GIFT buttons target a specific cellmate.',
  'Press INVITE on any protester\'s row to send them a cell invite — they get 20 seconds to answer the flyer.',
  'Press G for the emote wheel. Morale is a legitimate tactic.',
  'Press M for the big map — checkpoints, tokens and chasers, beautifully framed.',
  'The journalist archetype spots police on the minimap from farther away. Bring one. Or become one.',
]

export default function SquadPanel() {
  const squadOpen = useGameStore((s) => s.squadOpen)
  const toggleSquad = useGameStore((s) => s.toggleSquad)
  const hud = useGameStore((s) => s.hud)
  const squad = useGameStore((s) => s.squad)
  const matchMode = useGameStore((s) => s.matchMode)
  const season = useGameStore((s) => s.season)
  const roomRoster = useGameStore((s) => s.roomRoster)
  const [joinCode, setJoinCode] = useState('')
  const [copied, setCopied] = useState(false)
  const [linkCopied, setLinkCopied] = useState(false)
  const [now, setNow] = useState(Date.now())

  // cheap ticker for the rally cooldown countdown
  useEffect(() => {
    if (!squadOpen) return
    const t = window.setInterval(() => setNow(Date.now()), 500)
    return () => window.clearInterval(t)
  }, [squadOpen])

  if (!squadOpen) return null

  const copyCode = async () => {
    if (!squad?.code) return
    try {
      await navigator.clipboard.writeText(squad.code)
    } catch {
      const ta = document.createElement('textarea')
      ta.value = squad.code
      document.body.appendChild(ta)
      ta.select()
      document.execCommand('copy')
      ta.remove()
    }
    setCopied(true)
    window.setTimeout(() => setCopied(false), 2000)
  }

  /** Copy a ?squad= deep link — recipients auto-join this cell after entering any room. */
  const copyInviteLink = async () => {
    if (!squad?.code) return
    const url = `${window.location.origin}/?squad=${squad.code}`
    try {
      await navigator.clipboard.writeText(url)
    } catch {
      const ta = document.createElement('textarea')
      ta.value = url
      document.body.appendChild(ta)
      ta.select()
      document.execCommand('copy')
      ta.remove()
    }
    setLinkCopied(true)
    useGameStore.getState().notify('Invite link copied — send it to your comrades!', 'squad')
    window.setTimeout(() => setLinkCopied(false), 2000)
  }

  const squadById = new Map((squad?.members ?? []).map((m) => [m.id, m]))

  return (
    <div className="pointer-events-none fixed inset-0 z-30 flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="vc-paper pointer-events-auto max-h-[86vh] w-[min(430px,92vw)] overflow-y-auto vc-scroll rounded-2xl border-2 border-[#1c1a17]/80 p-4 shadow-[6px_6px_0_rgba(28,26,23,0.85)]"
      >
        <div className="mb-2 flex items-center justify-between">
          <h3 className="flex items-center gap-2 text-base font-black uppercase tracking-tight text-[#1c1a17]">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg border-2 border-[#1c1a17]/70 bg-[#2e6e4e] text-[#f5efdc]">
              <HeartPulse className="h-4 w-4" />
            </span>
            Squad Status
          </h3>
          <button onClick={() => toggleSquad(false)} className="text-[#1c1a17]/50 hover:text-[#8c1f28]" aria-label="Close squad panel">
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* ---------- squad cell management (multiplayer rooms + seasons) ---------- */}
        {(matchMode === 'multiplayer' || season) && (
          <div className="mb-3 rounded-xl border-2 border-[#1c1a17]/70 bg-[#efe6cd] p-2.5">
            {squad ? (
              <>
                <div className="mb-2 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <span className="flex h-6 w-6 items-center justify-center rounded-lg border-2 border-[#1c1a17]/70 bg-[#f2c14e]">
                      <Users className="h-3.5 w-3.5 text-[#1c1a17]" />
                    </span>
                    <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#1c1a17]/70">Protest cell</span>
                  </div>
                  {/* dashed protest-ticket code chip + copy + invite link */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={copyCode}
                      aria-label={`Copy squad code ${squad.code}`}
                      className="group flex items-center gap-1.5 rounded-lg border-2 border-dashed border-[#8c1f28] bg-[#f5efdc] px-2.5 py-1 shadow-[2px_2px_0_rgba(28,26,23,0.6)] transition-transform hover:-rotate-1 hover:scale-[1.03] active:rotate-0"
                    >
                      <span className="font-mono text-sm font-black tracking-[0.25em] text-[#8c1f28]">{squad.code}</span>
                      {copied ? <Check className="h-3.5 w-3.5 text-[#2e6e4e]" /> : <Copy className="h-3.5 w-3.5 text-[#1c1a17]/50 group-hover:text-[#1c1a17]" />}
                    </button>
                    <button
                      onClick={copyInviteLink}
                      aria-label="Copy cell invite link"
                      title="Copy a link that auto-joins this cell (opens with ?squad param)"
                      className={`flex h-7 w-7 items-center justify-center rounded-lg border-2 shadow-[2px_2px_0_rgba(28,26,23,0.5)] transition-all ${
                        linkCopied
                          ? 'border-[#2e6e4e] bg-[#dcebe0] text-[#2e6e4e]'
                          : 'border-[#1c1a17]/60 bg-[#f5efdc] text-[#1c1a17]/60 hover:-translate-y-0.5 hover:border-[#2e6e4e] hover:text-[#2e6e4e]'
                      }`}
                    >
                      {linkCopied ? <Check className="h-3.5 w-3.5" /> : <Link2 className="h-3.5 w-3.5" />}
                    </button>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-bold uppercase tracking-widest text-[#1c1a17]/50">
                    {squad.members.length}/4 members · share the code or link
                  </span>
                  <div className="flex items-center gap-1.5">
                    {/* gifting perk — hand an item to the nearest live teammate (§11) */}
                    <button
                      onClick={() => uiActions().giftNearest()}
                      disabled={hud.detained || hud.inventory.length === 0}
                      title={
                        hud.detained
                          ? 'Cannot gift while detained'
                          : hud.inventory.length === 0
                            ? 'Pockets are empty — nothing to gift'
                            : 'Gift your best item to the nearest teammate (F)'
                      }
                      className={`flex items-center gap-1 rounded-lg border-2 px-2 py-1 text-[9px] font-black uppercase tracking-widest shadow-[2px_2px_0_rgba(28,26,23,0.5)] transition-all ${
                        hud.detained || hud.inventory.length === 0
                          ? 'cursor-not-allowed border-[#1c1a17]/40 bg-[#e7dfc9] text-[#1c1a17]/40'
                          : 'border-[#1c1a17]/70 bg-[#7de3a8] text-[#1c1a17] hover:-translate-y-0.5 hover:bg-[#a7efc3]'
                      }`}
                    >
                      <Gift className="h-3 w-3" /> Gift
                    </button>
                    {/* rally perk — teleport to nearest free cellmate, 45s cooldown */}
                    {(() => {
                      const remainMs = hud.rallyReadyAt - now
                      const cooling = remainMs > 0
                      const cellmatesFree = squad.members.length > 1 && !hud.detained
                      return (
                        <button
                          onClick={() => uiActions().rallyToCell()}
                          disabled={cooling || !cellmatesFree}
                          title={
                            hud.detained
                              ? 'Cannot rally while detained'
                              : cooling
                                ? `Rally recharging — ${Math.ceil(remainMs / 1000)}s`
                                : 'Teleport to the nearest free cellmate'
                          }
                          className={`flex items-center gap-1 rounded-lg border-2 px-2 py-1 text-[9px] font-black uppercase tracking-widest shadow-[2px_2px_0_rgba(28,26,23,0.5)] transition-all ${
                            cooling || !cellmatesFree
                              ? 'cursor-not-allowed border-[#1c1a17]/40 bg-[#e7dfc9] text-[#1c1a17]/40'
                              : 'border-[#1c1a17]/70 bg-[#f2c14e] text-[#1c1a17] hover:-translate-y-0.5 hover:bg-[#f2a541]'
                          }`}
                        >
                          <Megaphone className="h-3 w-3" />
                          {cooling ? `${Math.ceil(remainMs / 1000)}s` : hud.detained ? 'Rally' : 'Rally!'}
                        </button>
                      )
                    })()}
                    <button
                      onClick={() => { setJoinCode(''); uiActions().squadLeave() }}
                      className="flex items-center gap-1 rounded-lg border-2 border-[#1c1a17]/60 bg-[#e7dfc9] px-2 py-1 text-[9px] font-black uppercase tracking-widest text-[#1c1a17]/80 shadow-[2px_2px_0_rgba(28,26,23,0.5)] transition-colors hover:bg-[#f2c14e]"
                    >
                      <LogOut className="h-3 w-3" /> Leave squad
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="mb-1.5 flex items-center gap-1 text-[10px] font-black uppercase tracking-[0.2em] text-[#1c1a17]/70">
                  <Flag className="h-3.5 w-3.5 text-[#2e6e4e]" /> Form a protest cell (max 4)
                </div>
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    onClick={() => uiActions().squadCreate()}
                    className="flex items-center gap-1 rounded-lg border-2 border-[#1c1a17]/70 bg-[#2e6e4e] px-2.5 py-1.5 text-[10px] font-black uppercase tracking-widest text-[#f5efdc] shadow-[2px_2px_0_rgba(28,26,23,0.7)] transition-transform hover:-translate-y-0.5"
                  >
                    <Users className="h-3 w-3" /> Create squad
                  </button>
                  <div className="flex items-center gap-1 rounded-lg border-2 border-dashed border-[#1c1a17]/50 bg-[#f5efdc] px-1.5 py-0.5">
                    <Ticket className="h-3.5 w-3.5 text-[#1c1a17]/50" />
                    <input
                      value={joinCode}
                      onChange={(e) => setJoinCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4))}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && joinCode.length === 4) uiActions().squadJoin(joinCode)
                      }}
                      placeholder="CODE"
                      aria-label="Squad join code"
                      maxLength={4}
                      className="w-16 bg-transparent text-center font-mono text-sm font-black tracking-[0.2em] text-[#8c1f28] outline-none placeholder:text-[#1c1a17]/30"
                    />
                    <button
                      onClick={() => { if (joinCode.length === 4) uiActions().squadJoin(joinCode) }}
                      disabled={joinCode.length !== 4}
                      className="rounded border-2 border-[#1c1a17]/60 bg-[#f2c14e] px-1.5 py-0.5 text-[9px] font-black uppercase tracking-widest text-[#1c1a17] disabled:opacity-40"
                    >
                      Join
                    </button>
                  </div>
                </div>
                <p className="mt-1 text-[9px] font-semibold text-[#1c1a17]/50">
                  Squadmates get green name tags and squad toasts. Create one, share the code — or press INVITE on any protester&rsquo;s row below.
                </p>
              </>
            )}
          </div>
        )}
        {matchMode !== 'multiplayer' && !season && (
          <p className="mb-3 rounded-xl border-2 border-dashed border-[#1c1a17]/40 bg-[#efe6cd]/60 px-3 py-2 text-center text-[10px] font-bold uppercase tracking-widest text-[#1c1a17]/55">
            Squads are a multiplayer feature — rally in a room first
          </p>
        )}

        {/* ---------- season roster (solo queue: the 100-protester persistent world) ---------- */}
        {season && (() => {
          const humans = roomRoster.filter((p) => !p.bot)
          const bots = roomRoster.filter((p) => p.bot)
          const ordered = [...humans, ...bots]
          return (
            <div className="mb-3 rounded-xl border-2 border-[#8c1f28]/70 bg-[#efe6cd] p-2.5">
              <div className="mb-1.5 flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <span className="flex h-6 w-6 items-center justify-center rounded-lg border-2 border-[#1c1a17]/70 bg-[#8c1f28]">
                    <Globe className="h-3.5 w-3.5 text-[#f5efdc]" />
                  </span>
                  <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#1c1a17]/70">{season.name}</span>
                </div>
                <span className="text-[9px] font-black tabular-nums text-[#8c1f28]">
                  {season.humans + season.bots}/{season.cap} · {season.humans} human{season.humans === 1 ? '' : 's'}
                </span>
              </div>
              {/* population meter — gold humans over maroon bots */}
              <div className="mb-2 flex h-2 overflow-hidden rounded-full border border-[#1c1a17]/50 bg-[#1c1a17]/20">
                <div className="h-full bg-[#f2c14e] transition-[width] duration-500" style={{ width: `${(season.humans / Math.max(1, season.cap)) * 100}%` }} />
                <div className="h-full bg-[#b3552e] transition-[width] duration-500" style={{ width: `${(season.bots / Math.max(1, season.cap)) * 100}%` }} />
                <div className="h-full flex-1" />
              </div>
              <div className="mb-1 flex items-center justify-between px-0.5">
                <span className="flex items-center gap-1 text-[9px] font-black uppercase tracking-[0.2em] text-[#1c1a17]/50">
                  <BotIcon className="h-3 w-3" /> Roster · bots fill empty slots
                </span>
                <span className="text-[9px] font-bold uppercase tracking-widest text-[#1c1a17]/40">{ordered.length} in season</span>
              </div>
              <div className="vc-scroll max-h-52 space-y-1 overflow-y-auto pr-1">
                {ordered.map((p) => (
                  <div
                    key={p.id}
                    className={`flex items-center gap-2 rounded-lg border px-2 py-1 ${
                      p.bot ? 'border-[#1c1a17]/40 bg-[#f5efdc]/70' : 'border-[#2e6e4e] bg-[#dcebe0]'
                    }`}
                  >
                    <span
                      className="h-4 w-4 shrink-0 rounded-full border-2 border-[#1c1a17]/50"
                      style={{ background: archetypeById(p.archetype || 'student').colors.shirt }}
                    />
                    <span className="min-w-0 flex-1 truncate text-[10px] font-black uppercase tracking-tight text-[#1c1a17]/85">{p.name}</span>
                    {p.bot ? (
                      <span className="rounded border border-[#1c1a17]/50 bg-[#e7dfc9] px-1 text-[8px] font-black uppercase tracking-wider text-[#1c1a17]/60">Bot</span>
                    ) : (
                      <span className="rounded border border-[#2e6e4e] bg-[#2e6e4e] px-1 text-[8px] font-black uppercase text-[#f5efdc]">Human</span>
                    )}
                  </div>
                ))}
              </div>
              <p className="mt-1.5 text-[9px] font-semibold text-[#1c1a17]/55">
                When a protester leaves, a bot walks in from the plaza. When a real player joins, a bot steps aside. The season never sleeps.
              </p>
            </div>
          )
        })()}

        {hud.squad.length === 0 ? (
          <p className="rounded-xl border-2 border-dashed border-[#1c1a17]/40 px-3 py-4 text-center text-xs font-bold text-[#1c1a17]/60">
            {season
              ? 'No protesters close enough to show status — walk toward the crowd!'
              : 'You are protest-soloing right now. Join a multiplayer room to get squadmates — and witnesses.'}
          </p>
        ) : (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between px-0.5">
              <span className="text-[9px] font-black uppercase tracking-[0.2em] text-[#1c1a17]/50">Protesters in the room</span>
              <span className="text-[9px] font-bold uppercase tracking-widest text-[#1c1a17]/40">Invite or gift →</span>
            </div>
            {hud.squad.map((m) => {
              const arch = archetypeById(m.archetype || 'student')
              const inCell = squadById.has(m.id)
              return (
                <div
                  key={m.id}
                  className={`flex items-center gap-2.5 rounded-xl border px-2.5 py-1.5 transition-colors ${
                    inCell ? 'border-[#2e6e4e] bg-[#2e6e4e]/10' : 'border-[#1c1a17]/60 bg-[#f5efdc]'
                  }`}
                >
                  <span
                    className="h-6 w-6 shrink-0 rounded-full border-2"
                    style={{ background: arch.colors.shirt, borderColor: inCell ? '#2e6e4e' : 'rgba(28,26,23,0.6)' }}
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="truncate text-xs font-black uppercase tracking-tight text-[#1c1a17]">{m.name}</span>
                      {inCell && (
                        <span className="rounded border border-[#2e6e4e] bg-[#2e6e4e] px-1 text-[8px] font-black uppercase text-[#f5efdc]">
                          Cell
                        </span>
                      )}
                      {m.detained && (
                        <span className="flex items-center gap-0.5 rounded border border-[#8c1f28] bg-[#8c1f28] px-1 text-[8px] font-black uppercase text-[#f5efdc]">
                          <ShieldAlert className="h-2.5 w-2.5" /> Detained
                        </span>
                      )}
                      {m.dazed && !m.detained && (
                        <span className="rounded border border-[#b07d1e] bg-[#f2c14e] px-1 text-[8px] font-black uppercase text-[#1c1a17]">Dazed</span>
                      )}
                    </div>
                    <div className="mt-0.5 flex items-center gap-1.5">
                      <div className="h-1.5 w-20 overflow-hidden rounded-full border border-[#1c1a17]/50 bg-[#1c1a17]/15">
                        <div className="h-full bg-[#4e9b6e]" style={{ width: `${Math.max(0, Math.min(100, m.health))}%` }} />
                      </div>
                      <span className="flex items-center gap-0.5 text-[9px] font-bold tabular-nums text-[#1c1a17]/60">
                        <Route className="h-2.5 w-2.5" /> {Math.round(m.distance)}m
                      </span>
                    </div>
                  </div>
                  {/* per-row actions: INVITE outsiders into the cell / GIFT cellmates directly (§15 + §11) — bots are not invitable */}
                  {m.bot ? (
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border-2 border-[#1c1a17]/20 bg-[#e7dfc9]/60 text-[#1c1a17]/35" title="Season bot — cheering from the sidelines">
                      <BotIcon className="h-3.5 w-3.5" />
                    </span>
                  ) : inCell ? (
                    <button
                      onClick={() => uiActions().giftTo(m.id)}
                      disabled={hud.detained || hud.inventory.length === 0 || m.detained}
                      title={
                        hud.detained
                          ? 'Cannot gift while detained'
                          : m.detained
                            ? `${m.name} is detained — bail them out first`
                            : hud.inventory.length === 0
                              ? 'Pockets are empty — nothing to gift'
                              : `Gift your best item to ${m.name}`
                      }
                      aria-label={`Gift an item to ${m.name}`}
                      className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border-2 shadow-[2px_2px_0_rgba(28,26,23,0.5)] transition-all ${
                        hud.detained || hud.inventory.length === 0 || m.detained
                          ? 'cursor-not-allowed border-[#1c1a17]/30 bg-[#e7dfc9] text-[#1c1a17]/30'
                          : 'border-[#1c1a17]/70 bg-[#7de3a8] text-[#1c1a17] hover:-translate-y-0.5 hover:bg-[#a7efc3]'
                      }`}>
                      <Gift className="h-3.5 w-3.5" />
                    </button>
                  ) : (
                    <button
                      onClick={() => uiActions().squadInvite(m.id)}
                      disabled={Boolean(squad && squad.members.length >= 4)}
                      title={
                        squad && squad.members.length >= 4
                          ? 'Your cell is full (4 max)'
                          : `Invite ${m.name} to cell ${squad?.code ?? ''} (20s to answer)`
                      }
                      aria-label={`Invite ${m.name} to your squad`}
                      className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border-2 shadow-[2px_2px_0_rgba(28,26,23,0.5)] transition-all ${
                        squad && squad.members.length >= 4
                          ? 'cursor-not-allowed border-[#1c1a17]/30 bg-[#e7dfc9] text-[#1c1a17]/30'
                          : 'border-[#8c1f28]/70 bg-[#f5d9d4] text-[#8c1f28] hover:-translate-y-0.5 hover:bg-[#efc4bc]'
                      }`}>
                      <UserPlus className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              )
            })}
          </div>
        )}

        <div className="mt-3 space-y-1 rounded-xl border-2 border-dashed border-[#8c1f28]/40 bg-[#f2c14e]/25 p-2.5">
          <div className="flex items-center gap-1 text-[9px] font-black uppercase tracking-[0.2em] text-[#8c1f28]">
            <KeyRound className="h-3 w-3" /> Squad field manual
          </div>
          {TIPS.map((t, i) => (
            <p key={i} className="text-[10px] font-semibold leading-snug text-[#1c1a17]/75">• {t}</p>
          ))}
        </div>
        <p className="mt-1.5 text-center text-[9px] font-bold uppercase tracking-widest text-[#1c1a17]/40">Tab to close</p>
      </motion.div>
    </div>
  )
}
